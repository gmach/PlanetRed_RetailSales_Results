$(function(){
	app.init();
	app.template.init();
	app.modal.init();
	app.menu.init();
	app.chart.init();
	app.collapse.init();
});