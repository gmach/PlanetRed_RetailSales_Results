/*
	name: 		template.js
	feature:    Template functions
	author:     James Cooke (james@hellohuman.com.au)
*/

app.template = (function (api) {

	var config, pvt = {};
	
	// private variables and functions
	api.init = function () {
		config = {
			tempURL: (window.location.host === "vodastats.dev" || window.location.protocol.indexOf('file') > -1 ? "http://hellohuman.com.au/previews/vodafone/planetred/" : "")
		};
		pvt.setup();
	};
	
	pvt.setup = function(){
		// Register Helpers
		api.helpers();
		
		// Create templates
		api.create();
	};
	
	api.create = function(data){
	
		// Loop through the template wrappers
		$(".js-template").each(function(i, element){
			
			var $wrapper = $(element);
			
			// Grab the template and compile
			var $tmpl = api.compile($("#" + $wrapper.data("template-name")).html());
			
			if(typeof data === "undefined"){
				api.grab($wrapper, $tmpl);
			}
			
		});
	};
	
	api.grab = function($wrapper, $tmpl){
	
		app.loading();
		
		return $.getJSON(config.tempURL + $wrapper.data("template-data"), function(data){ api.grab.callback(data, $wrapper, $tmpl); });
	};
	
	api.compile = function($tmpl){
		return Handlebars.compile($tmpl);
	};
	
	api.grab.callback = function(data, $wrapper, $tmpl){
	
		$wrapper.html($tmpl(data));
		app.loaded();
		
		// Check if there is any oncomplete shouts
		if(typeof $wrapper.data("template-oncomplete") !== "undefined"){
			app.shout($wrapper.data("template-oncomplete"), [$wrapper]);
		}
	};

	
	api.helpers = function(){
	
		// Break out if handlebars is not defined for any reason
		if(typeof Handlebars === "undefined"){ return;}
	
		Handlebars.registerHelper('setIndex', function(value){
			return this.index = Number(value + 1);
		});	
		
		Handlebars.registerHelper('numFormatting', function(value){
			var val = api.abbreviateNumber(value).toString().split(".");
						
			if(typeof val[1] === "undefined"){ return val; }
						
			return val[0] + "<em>." + val[1] + "</em>";
		});
		
		Handlebars.registerHelper('equal', function(lvalue, rvalue, options) {
		    if (arguments.length < 3)
		        throw new Error("Handlebars Helper equal needs 2 parameters");
		    if( lvalue!=rvalue ) {
		        return options.inverse(this);
		    } else {
		        return options.fn(this);
		    }
		});
		
		Handlebars.registerHelper('statLabel', function(context, value){
		
			// Array of labels for the cards
			var labels = {
				wtd:{
					today: "Today",
					rolling: "Last 7",
					week: "This week",
					month: "This month"
				},
				prev: {
					today: "Last Week",
					rolling: "Previous 7",
					week: "Last week",
					month: "Last month"
				}
			}
			
			// Check if wtd is being passed, just in case
			if(typeof value.hash.wtd === "undefined"){ value.hash.wtd = false;}
			
			// Return the label
			return (value.hash.wtd === "true" ? labels.wtd[context] : labels.prev[context]);
		});	
		
		Handlebars.registerHelper("getRowIndex", function(value){
			console.log(value);
		});
		
		Handlebars.registerHelper('getArrow', function(value){
			
			var arrows = {
				"up": "&#59231;",
				"down": "&#59228",
				"same": "&#9205;"
			}
			
			return arrows[value];
		});	
		
	};
	
	api.abbreviateNumber = function(num) {
	
	    if (num >= 1000000000) {
	        return (num / 1000000000).toFixed(1).replace(/\.0$/, '') + 'G';
	     }
	     if (num >= 1000000) {
	        return (num / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
	     }
	     if (num >= 1000) {
	        return (num / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
	     }
	     
	     return num;
	}
	

	return api;

})(app.template || {});