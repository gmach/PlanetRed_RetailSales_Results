/*
	name: 		modal.js
	feature:    Modal functions
	author:     James Cooke (james@hellohuman.com.au)
*/

app.modal = (function (api) {

	var config, pvt = {};
	
	// private variables and functions
	api.init = function () {
		config = {

		};
		pvt.setup();
	};
	
	pvt.setup = function(){
		api.links();
	};
	
	api.links = function(){
	
		$(document.body).on("click", '.js-modal', function(){ api.run(this); }); 
	};
	
	// TIDY TIDY TIDY
	api.run = function(el){
	
		var overlay = document.querySelector( '.md-overlay' );
	
		var modal = document.querySelector( '#modal'),
			close = modal.querySelector( '.md-close' );

		function removeModal( hasPerspective ) {
			classie.remove( modal, 'md-show' );
			
			$(document.body).removeClass("md-show");

			if( hasPerspective ) {
				classie.remove( document.documentElement, 'md-perspective' );
			}
		}

		function removeModalHandler() {
			removeModal( classie.has( el, 'md-setperspective' ) ); 
		}


		$(document.body).addClass("md-show");
		
		classie.add( modal, 'md-show' );
		overlay.removeEventListener( 'click', removeModalHandler );
		overlay.addEventListener( 'click', removeModalHandler );

		if( classie.has( el, 'md-setperspective' ) ) {
			setTimeout( function() {
				classie.add( document.documentElement, 'md-perspective' );
			}, 25 );
		}


		close.addEventListener( 'click', function( ev ) {
			ev.stopPropagation();
			removeModalHandler();
		});	
		
	};
	
	return api;

})(app.modal || {});