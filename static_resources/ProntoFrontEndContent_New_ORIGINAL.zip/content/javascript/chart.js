/*
	name: 		chart.js
	feature:    Chart setup and styling
	author:     James Cooke (james@hellohuman.com.au)
*/

app.chart = (function (api) {

	var config, pvt = {};
	
	// private variables and functions
	api.init = function () {
		config = {
			doughnut:{
				colors:["#BDC8D7", "#E2EAE9", "#88909A", "#949FB1","#4D5360"]
			},
			bar:{
				colors:{
					fill:["#F7464A", "#E2EAE9"],
					stroke:["#F7464A", "#E2EAE9"]
				}
			}
		};
		pvt.setup();
	};
	
	pvt.setup = function(){
	
		$(".js-chart").each(function(){
			
			var $chart = $(this);
			
			// Break out if we don't want this called onload
			if($chart.data("chart-onload")	=== false ){ return; }
			
			// Create the 
			api.create($chart);
		});
		
		$(".js-chart-mini").each(function(){
			api.create.mini($(this));
		});
		
		pvt.listeners();
	};
	
	pvt.listeners = function(){
		app.listen("/chart/create", function(context, object){ api.create(object); });
		app.listen("/chart/create/mini", function(context, object){ api.create.mini(object); });
		app.listen("/chart/reset", function(context, object){ pvt.reset(object); });	
	};
	
	// Create: Create a chart from a passed div element
	api.create = function($chart){
		
		// Check if chart has already been created
		if($chart.data("chart-ready") === true){ return; }
		
		// Pass multiple chart type handlers when we add them
		var typeSetup = {
			doughnut: api.pie
		};
		
		// Make sure we have the handler setup
		if(typeof $chart.data("chart-type") !== "undefined"){
			typeSetup[$chart.data("chart-type")].apply($chart);
		}
		
		// Set a flag to show the chart has been created
		$chart.data("chart-ready", true);
    };

	// Create > Mini: For creating mini charts using piety    
    api.create.mini = function($chart){ 
		

		// If we are being passed a wrapper and not a chart clear the $chart and pass js-chart-mini instead
		if(!$chart.hasClass("js-chart-mini")){
			var $chart = $chart.find(".js-chart-mini");
		}
		
		$chart.peity(
			$chart.data("chart-type"), {
				width:"100%", 
				height:60,
				colour: $chart.data("chart-color"),
				strokeColour: $chart.data("chart-stroke"),
				strokeWidth: 4
			}
		);
    };
    
    // Create > Doughnut: Create a lovely doughnut chart
    api.pie = function(){
    
    	var $chart = this,
	    	
	    	// Loop through the data-tag and build the chart data
	    	data = $.makeArray(api.pie.data($chart)),
	    	
	    	// Setup a new Chart - chart.js needs this to reset charts
	    	chartElement = new Chart(pvt.getCanvas($chart));
	    	
	    // Build the doughnut
		chartElement.Pie(data, { 
			animationSteps : 34, 
			animationEasing : "easeOutQuart"
		});
    };
    
    // Create > Doughnut > Data: Grab the chart data from the data tag
    api.pie.data = function($chart){
    	
		var data = $chart.data("chart-values").split(","),
			returnData = [];
		
		// Loop through the comma separated array and build the values and colors that chart.js needs
		$(data).each(function(i, dataItem){
			returnData.push({value: parseInt(dataItem), color: config.doughnut.colors[i]});
		});
		
		return returnData;
    };
    
    // Reset: Reset a given wrapper's canvas element and re-create
    pvt.reset = function($chart){
		pvt.resetCanvas($chart);
		
		// Now create the chart
		api.create($chart);  
    };
    
    // Reset Canvas: Reset the canvas area and redraw
    pvt.resetCanvas = function($chart){
    	var canvas = pvt.getCanvas($chart);
		canvas.clearRect(0, 0, canvas.width, canvas.height);  
    };
    
    // Get Canvas: Return the 2d canvas element required by chart.js
    pvt.getCanvas = function($chart){
		return $chart.get(0).getContext("2d");
    };
    
	return api;

})(app.chart || {});