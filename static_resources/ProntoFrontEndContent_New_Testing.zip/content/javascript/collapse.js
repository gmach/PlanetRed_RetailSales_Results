/*
	name: 		collapse.js
	feature:    Collapser functions
	author:     James Cooke (james@hellohuman.com.au)
*/

app.collapse = (function (api) {

	var config, pvt = {};
	
	// private variables and functions
	api.init = function () {
		config = {
			scrollContainer: ".owl-item"
		};
		pvt.setup();
	};
	
	pvt.setup = function(){
		pvt.links();
	};
	
	pvt.links = function(){
		if(Modernizr.touch){
			$(document.body).hammer().on("release", ".js-collapse", api.toggle);
		} else{
			$(document.body).on("click", ".js-collapse", api.toggle);
		}
	};
	
	api.toggle = function(e){
	
		e.preventDefault();
		
		// Check if this is a touch gesture and the hand has moved too far (hence a swipe) then break out
		if(typeof e.gesture !== "undefined" && e.gesture.distance > 20){ return; }
		
		var $link = $(this);
		
		// Quick fix for clicking within chart area
		if($(e.target).closest(".stat-chart").length > 0) {return;}
		
		// Add an on class if it doesnt have one already
		$link.toggleClass("on");
		
		api.toggle.classes($link);
		
		api.toggle.text($link);
		
		api.toggle.target($link);
		
		api.toggle.similar($link);
	};
	
	api.toggle.classes = function($link){
	
		// Check if we want to change the class, otherwise breakout
		if(typeof $link.data("collapse-class") === "undefined"){ return; }	
		
		// Work out what we want to replace and with what
		var classNames = $link.data("collapse-class").split(":");
		
		// If we are collapsing, flip the array
		if(!$link.hasClass("on")){
			classNames.reverse();
		}
		
		$link.removeClass(classNames[0]).addClass(classNames[1]);
		
	};
	
	api.toggle.text = function($link){
	
		// Check if we want to change the text, otherwise breakout
		if(typeof $link.data("collapse-text") === "undefined"){ return; }
			
		// Only set orig text the first time
		if(typeof $link.data("collapse-orig-text") === "undefined"){
			$link.data("collapse-orig-text", $link.text());	
		}
		
		// Now change the text
		var text = ($link.text() === $link.data("collapse-text") ? $link.data("collapse-orig-text") : $link.data("collapse-text"));
		$link.text(text);
	};
	
	api.toggle.target = function($link){
		
		var target = $link.data("collapse"),
			$container;
		
		// Check if we are looking for a class within the collapse container
		if(target.substr(0,1) === "."){
			$container = $link.closest(".js-collapse-core").find(target);
		}
		
		// If we are looking for an id, look in the whole DOM
		if(target.substr(0,1) === "#"){
			$container = $(target);
		}
		
		$container.toggleClass("collapsed");
		
		if($container.data("collapse-haschart") === true){
			app.shout("/chart/create", [$container.find(".js-chart")]);
		}

	};
	
	api.toggle.similar = function($link){
		
		// Find other similar cards
		if(typeof $link.data("collapse-other") === "undefined"){ return; }
		
		$("[data-collapse-other='" + $link.data("collapse-other") + "']").not($link).each(function(i, element){
			api.toggle.target($(element));
		});
	};


	return api;

})(app.collapse || {});