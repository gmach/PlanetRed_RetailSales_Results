/*
	name: 		combined.js
	feature:    Used by CodeKit - for now - to combine and minify
	author:     James Cooke (james@hellohuman.com.au)

	// Library Files and Includes
	@codekit-append "lib/jquery.js"
	@codekit-append "lib/pubsub.js"
	@codekit-append "lib/hammer.js"
	@codekit-append "lib/handlebars.js"
	@codekit-append "lib/chart.js"
	@codekit-append "lib/classie.js"
	@codekit-append "lib/menu.js"
	@codekit-append "lib/modal.js"
	@codekit-append "lib/peity.js"
	
	// Start APP functions
	@codekit-append "app.js"
	@codekit-append "template.js"
	@codekit-append "collapse.js"
	@codekit-append "menu.js"
	@codekit-append "chart.js"
	@codekit-append "modal.js"
	@codekit-append "init.js"
*/
