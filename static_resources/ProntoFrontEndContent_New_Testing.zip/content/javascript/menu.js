/*
	name: 		menu.js
	feature:    Menu functions
	author:     James Cooke (james@hellohuman.com.au)
*/

app.menu = (function (api) {

	var config, pvt = {};
	
	// private variables and functions
	api.init = function () {
		config = {

		};
		pvt.setup();
	};
	
	pvt.setup = function(){
		api.create();
	};
	
	// Create: Setup mlPushMenu < Temp menu handler
	api.create = function(){
		
		if($("#js-menu-push").length > 0 && $("#mp-menu").length > 0){
		
			var menu = new mlPushMenu(document.getElementById('mp-menu'), document.getElementById('js-menu-push'), {
				type : 'cover'
			});	
		}
	};

	return api;

})(app.menu || {});