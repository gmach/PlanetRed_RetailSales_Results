/*
	name: 		app.js
	feature:    The Global APP wrapper
	author:     James Cooke (james@hellohuman.com.au)
*/

var app = (function (api) {

	var config, $cache, pvt = {};
	
	// private variables and functions
	api.init = function () {
		config = {
			touchnclick: (Modernizr.touch ? "touchend" : "click")
		};
		$cache = {
			container: $("#content")	
		};
		pvt.setup();
	};
	
	pvt.setup = function(){
		pvt.links();
		pvt.binds();
		$(window).load(api.hideAddressBar);
	};
	
	pvt.links = function(){
		$(document.body)
			.on("click", ".js-fakelink", api.fakeLink)
			.on("click", ".js-link", api.link)
			.on("click", ".js-tabbar", api.tabbar)
			.on("click", ".js-chatter", api.chatter.setPage);
	};
	
	pvt.binds = function(){

	};
	
	api.loading = function(){
		$("body").addClass("loading");
	};
	
	api.loaded = function(){
		$("body").removeClass("loading");
	};
	
	// responsive: Return the current responsive type based on 3 crude widths
	api.responsive = function(){
		
		var width = $(window).width();
	
		if(width < 480){ return "mobile"; }
		if(width < 680){ return "tablet"; }
		else{return "desktop";}
	};
	
	// Shout: Pubsub publish, shout out to all subscribers
	api.shout = function(context, object){
		return $.publish(context, object);
	};
	
	// Listen: Pubsub subscribe, listen to any events
	api.listen = function(context, callback){
		return $.subscribe(context, callback);
	};
	
	api.fakeLink = function(){
		window.location = $(this).data("fakelink-url");	
	};
	
	api.link = function(){
		window.location.href(this.href);	
	};
	
	api.tabbar = function(e){
	
		var $link = $(this),
			$container = $($link.data("tabbar-container"));
		
		// Set and Remove on classes
		$link.addClass("on").closest(".js-tabbar-core")
			.find(".on").not($link).removeClass("on");
			
		// Hide other sections
		$container.find(".tabbar-on").removeClass("tabbar-on");
		
		$container.find($link.data("tabbar-item")).addClass("tabbar-on");
		
		e.preventDefault();
			
	};
	
	api.chatter = function(){
		
	};
	
	api.chatter.setPage = function(){
		var $link = $(this);
		
		// Set the hidden include
		$("#chatter-form").find("#pageName").val($link.data("chatter-page"));	
	};
	
	
	api.hideAddressBar = function(){
		setTimeout(function(){ window.scrollTo(0,1); }, 100);
	};

	return api;

})(app || {});
